<?php
/*****
SUSTITUYE LAS XXX POR UN VALOR DE UNA NOTICIA DE INTERES EN ESTA CATEGORIA
*****/

$portada = [
"titulo" => "Diario El Hocicón, "Pobre, pero Honrado"",
"autor" => "XXXX",
"resumen" => "El resumen Febrero 2025",
];
?>
